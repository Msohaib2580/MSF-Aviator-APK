const multiplier = document.getElementById("multiplier");
const startBtn = document.getElementById("startBtn");

let value = 1.00;
let timer = null;

startBtn.addEventListener("click", function () {
    if (timer) {
        clearInterval(timer);
    }

    value = 1.00;
    multiplier.textContent = value.toFixed(2) + "x";

    timer = setInterval(function () {
        value += 0.01;
        multiplier.textContent = value.toFixed(2) + "x";

        if (value >= 10.00) {
            clearInterval(timer);
            timer = null;
        }
    }, 100);
});